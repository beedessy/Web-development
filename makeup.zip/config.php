<?php
	$conn = new mysqli("localhost","id17081298_root","Beedessyluck21.","id17081298_cart_system");
	if($conn->connect_error){
		die("Connection Failed!".$conn->connect_error);
	}
	
?>