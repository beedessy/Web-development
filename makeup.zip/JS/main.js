$('.carousel').carousel({
  interval: 20000
});